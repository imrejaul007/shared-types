# Bulk Products - Visual Guide

## 📥 Import Screen Layout

```
┌─────────────────────────────────────────┐
│  ← Import Products           📥         │
├─────────────────────────────────────────┤
│                                         │
│  ℹ️ Instructions                        │
│  1. Download the CSV/Excel template     │
│  2. Fill in your product data           │
│  3. Upload the completed file           │
│  4. Review validation results           │
│  5. Fix any errors and re-import        │
│                                         │
│  ┌────────────────────────────────┐    │
│  │  📥 Download Template          │    │
│  └────────────────────────────────┘    │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │        📄 Select File            │   │
│  │                                  │   │
│  │     ☁️ Tap to select file        │   │
│  │  CSV or Excel files only         │   │
│  │                                  │   │
│  └─────────────────────────────────┘   │
│                                         │
│  OR (if file selected)                  │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │  📄 products.csv          ✓ ❌  │   │
│  │  245 KB                          │   │
│  └─────────────────────────────────┘   │
│                                         │
│  Import Progress                        │
│  ████████████████░░░░░░░░  75%         │
│  ⏳ Processing products...              │
│                                         │
│  Import Results                         │
│  ┌──────────────────────────────────┐  │
│  │ Total: 250 | Success: 245 | ❌: 5 │  │
│  └──────────────────────────────────┘  │
│                                         │
│  ⚠️ Errors (5)                           │
│  ┌──────────────────────────────────┐  │
│  │ ⚠️ Line 12 | price                 │  │
│  │   Invalid price format            │  │
│  ├──────────────────────────────────┤  │
│  │ ⚠️ Line 45 | sku                   │  │
│  │   SKU already exists              │  │
│  └──────────────────────────────────┘  │
│                                         │
│  ┌────────────────────────────────┐    │
│  │    ☁️ Start Import              │    │
│  └────────────────────────────────┘    │
│                                         │
│  ▼ Show Import History                  │
│                                         │
│  products_batch_1.csv    [partial]      │
│  2025-11-15 14:30                       │
│  ✓ 245 successful  ✗ 5 failed           │
│                                         │
└─────────────────────────────────────────┘
```

## 📤 Export Screen Layout

```
┌─────────────────────────────────────────┐
│  ← Export Products                      │
├─────────────────────────────────────────┤
│                                         │
│  Export Format                          │
│  ┌────────────┐  ┌────────────┐        │
│  │     📄     │  │     📊     │        │
│  │    CSV     │  │   Excel    │        │
│  │  Selected  │  │            │        │
│  └────────────┘  └────────────┘        │
│                                         │
│  Filters (Optional)                     │
│  ┌─────────────────────────────────┐   │
│  │ 🏷️ Category: All categories     │   │
│  └─────────────────────────────────┘   │
│  ┌─────────────────────────────────┐   │
│  │ 🚩 Status: All statuses          │   │
│  └─────────────────────────────────┘   │
│  ┌──────────────┐ ┌──────────────┐    │
│  │ 📅 From Date │ │ 📅 To Date   │    │
│  └──────────────┘ └──────────────┘    │
│                                         │
│  ▼ Select Fields (7 selected)           │
│                                         │
│  [Select All]  [Deselect All]          │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ ✓ Product Name                   │   │
│  │ ✓ SKU                            │   │
│  │ ✓ Description                    │   │
│  │ ✓ Category                       │   │
│  │ ✓ Price                          │   │
│  │ ✓ Stock                          │   │
│  │ ✓ Status                         │   │
│  │ ☐ Images                         │   │
│  │ ☐ Tags                           │   │
│  │ ☐ Cashback                       │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌────────────────────────────────┐    │
│  │    📥 Export Products           │    │
│  └────────────────────────────────┘    │
│                                         │
│  ▼ Show Export History                  │
│                                         │
│  📄 products_export_2025-11-17.csv      │
│  2025-11-17 10:30                       │
│  1234 records exported                  │
│  📥 Download Again                       │
│                                         │
└─────────────────────────────────────────┘
```

## ⚡ Bulk Actions Screen Layout

```
┌─────────────────────────────────────────┐
│  ← Bulk Actions                         │
├─────────────────────────────────────────┤
│                                         │
│  🔍 Search products...                  │
│                                         │
│  ┌──────────────┐ ┌──────────────┐    │
│  │ Category     │ │ Status       │    │
│  └──────────────┘ └──────────────┘    │
│                                         │
├─────────────────────────────────────────┤
│  45 of 250 selected                     │
│  [Select All]  [Deselect All]          │
├─────────────────────────────────────────┤
│                                         │
│  Products (250)                         │
│  ┌─────────────────────────────────┐   │
│  │ ✓ Product 1                      │   │
│  │   Electronics • ₹999 • Stock: 10 │   │
│  │                           [active] │  │
│  ├─────────────────────────────────┤   │
│  │ ✓ Product 2                      │   │
│  │   Fashion • ₹499 • Stock: 25     │   │
│  │                           [active] │  │
│  ├─────────────────────────────────┤   │
│  │ ☐ Product 3                      │   │
│  │   Home • ₹299 • Stock: 5         │   │
│  │                         [inactive] │  │
│  └─────────────────────────────────┘   │
│                                         │
│  Select Action                          │
│  ┌──────────┐ ┌──────────┐            │
│  │ 🏷️       │ │ 💰       │            │
│  │ Category │ │  Price   │            │
│  └──────────┘ └──────────┘            │
│  ┌──────────┐ ┌──────────┐            │
│  │ 🔄       │ │ 🎁       │            │
│  │  Status  │ │ Discount │            │
│  └──────────┘ └──────────┘            │
│  ┌──────────┐                          │
│  │ 🗑️       │                          │
│  │  Delete  │                          │
│  └──────────┘                          │
│                                         │
│  Action Details                         │
│  ┌─────────────────────────────────┐   │
│  │ New Category:                    │   │
│  │ [Electronics                  ]  │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌────────────────────────────────┐    │
│  │ ✓ Apply to 45 Product(s)       │    │
│  └────────────────────────────────┘    │
│                                         │
│  ▼ Show Action History                  │
│                                         │
│  Changed category to Electronics        │
│  2025-11-17 10:30                       │
│  45 products affected      [completed]  │
│  ↩️ Undo Action                          │
│                                         │
└─────────────────────────────────────────┘
```

## 🎨 Color Coding

### Status Colors:
- 🟢 **Green** - Success, Active, Completed
- 🟡 **Yellow/Amber** - Warning, Partial, Inactive
- 🔴 **Red** - Error, Failed, Destructive actions
- 🔵 **Blue** - Info, Processing
- 🟣 **Purple** - Primary actions, Selected

### Icons:
- ✓ - Success/Selected
- ❌ - Error/Failed
- ⚠️ - Warning
- ℹ️ - Information
- 📥 - Download/Import
- 📤 - Upload/Export
- 🔍 - Search
- 🏷️ - Category/Tag
- 💰 - Price/Money
- 🔄 - Status/Refresh
- 🎁 - Discount/Offer
- 🗑️ - Delete
- ↩️ - Undo
- ⏳ - Loading/Processing

## 📱 Screen States

### 1. Import Screen States

**Empty State:**
```
┌────────────────────────┐
│   ☁️                   │
│  Tap to select file    │
│  CSV or Excel only     │
└────────────────────────┘
```

**File Selected:**
```
┌────────────────────────┐
│ 📄 products.csv    ❌  │
│ 245 KB                 │
└────────────────────────┘
```

**Uploading:**
```
Import Progress
████████████░░░░  75%
⏳ Processing...
```

**Success:**
```
✓ Import Complete!
245 products imported
```

**Partial Success:**
```
⚠️ Import Completed
245 successful, 5 failed
Review errors below
```

### 2. Export Screen States

**Format Selection:**
```
Selected:        Not Selected:
┌──────────┐    ┌──────────┐
│  📄 CSV  │    │  📊      │
│ ▼▼▼▼▼▼▼▼ │    │  Excel   │
└──────────┘    └──────────┘
```

**Exporting:**
```
⏳ Preparing export...
Please wait
```

**Ready:**
```
✓ Export Ready!
┌──────────────────┐
│  📥 Download     │
└──────────────────┘
```

### 3. Bulk Actions States

**No Selection:**
```
0 of 250 selected
Please select products
```

**With Selection:**
```
45 of 250 selected
┌──────────┐
│ Continue │
└──────────┘
```

**Processing:**
```
Processing...
████████░░  80%
```

**Complete:**
```
✓ Action Complete!
45 products updated
```

## 🖱️ Interaction Patterns

### Selection:
```
Unselected → Tap → Selected
    ☐              ✓

Multi-select:
[Select All] → All checked
[Deselect All] → All unchecked
```

### Toggle:
```
CSV ⇄ Excel
Percentage ⇄ Fixed
Active ⇄ Inactive
```

### Expand/Collapse:
```
▼ Show History → ▲ Hide History
```

### Confirmation:
```
Action → ⚠️ Confirm? → Proceed/Cancel
```

## 📐 Layout Dimensions

### Touch Targets:
- Minimum: **44px × 44px**
- Buttons: **48px height**
- Icons: **24px** (standard)
- Large icons: **32px-48px**

### Spacing:
- Section padding: **16px**
- Item spacing: **8-12px**
- Card spacing: **12-16px**
- Large gaps: **24px**

### Typography:
- Title: **20px**, bold
- Section title: **18px**, semibold
- Body: **16px**, regular
- Caption: **14px**, regular
- Small: **12px**, regular
- Tiny: **10px**, semibold

## 🎯 User Flow

### Import Flow:
```
Start → Download Template → Fill Data
     → Upload File → Validate → Review Errors
     → Fix & Re-upload (if errors) → Success
```

### Export Flow:
```
Start → Select Format → Apply Filters
     → Select Fields → Export → Download
```

### Bulk Action Flow:
```
Start → Search/Filter → Select Products
     → Choose Action → Configure Details
     → Confirm → Apply → View Results
     → Undo (optional)
```

## 📊 Progress Indicators

### Linear Progress:
```
████████████████░░░░░░  75%
```

### States:
```
0%    - Not started
1-25% - Starting
26-50% - Processing
51-75% - Almost done
76-99% - Finishing
100%  - Complete
```

### With Labels:
```
Uploading...        ███████░░░  70%
Validating...       █████████░  90%
Importing...        ██████████ 100%
```

---

**This visual guide helps understand:**
- Screen layouts and structure
- Component placement
- User interaction patterns
- Visual feedback
- State transitions
- Accessibility considerations

**Use this guide when:**
- Implementing the UI
- Testing the screens
- Training users
- Creating documentation
- Designing similar features
